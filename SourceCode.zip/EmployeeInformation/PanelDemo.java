/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package EmployeeInformation;

import java.awt.*;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.*;
import javax.swing.JTable;
import javax.swing.table.TableColumn;

/**
 *
 *
 * @author ASIF
 */
public class PanelDemo extends JPanel {

    private ResultSet rs, rs1, rs2;
    private java.sql.Statement stmt, stmt1, stmt2;
    private Object[][] rows;
    private int totalRows = 0;
    private JTable jTable1;
    private JScrollPane jScrollPane1;
    private String[] columns = {"CURRENT DATE", "EMPLOYEE ID", "EMPLOYEE NAME", "ATTENDANCE MODE"};
    private String[] columns1 = {"DESIGNATION ID", "DESIGNATION NAME", "BASIC", "TA", "DA", "HRA", "MA", "TOTAL", "PF", "NET"};
    private String[] columns2 = {"EMPLOYEE ID", "EMPLOYEE NAME", "DES_ID", "ADDRESS", "DATE OF BIRTH", "DATE OF JOIN", "CONTACT", "EMAIL", "QUALIFICATION", "POST"};
    private String[] columns3 = {"LEAVE NO", "EMPLOYEE ID", "LEAVE TYPE", "START DATE", "END DATE", "ISSUE TYPE"};
    private String[] columns4 = {"LOAN ID", "EMPLOYEE ID", "LOAN DATE", "LOAN AMOUNT", "EXTRA CHARGE", "MONTH", "TOTAL LOAN AMOUNT", "LOAN REASON", "EMI RATE"};
    private String[] columns6 = {"LOAN ID", "EMPLOYEE ID", "LOAN PAYMENT DATE", "PAY AMOUNT", "CURRENT AMOUNT", "REMAINING MONTH"};
    private String[] columns5 = {"CURRENT MONTH", "EMPLOYEE ID", "ADVANCE", "BONUS", "NET", "SALARY ISSUEING DATE", "DEDUCTION AMOUNT"};
    private String sesc;
    public static int count1 = 0;
    public static int count2 = 0;
    public static boolean flag = false;

    PanelDemo() {
        setLayout(null);
        this.setBackground(new java.awt.Color(102, 0, 102));
        try {
            stmt = MdiWindow.con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "All Query", 0);
        }
    }

    public void atnAllRecord() throws SQLException {
        String str = "select * from empattendance order by cur_date desc";
        rs = stmt.executeQuery(str);
        for (int i = 0; rs.next(); i++) {
            totalRows += 1;
        }

        rows = new Object[totalRows][columns.length];
        rs.beforeFirst();
        for (int j = 0; rs.next(); j++) {
            String st = String.valueOf(rs.getDate(1));
            String st1 = st.substring(0, 4);
            String st2 = st.substring(5, 7);
            String st3 = st.substring(8, 10);
            String st4 = st3.concat("-").concat(st2).concat("-").concat(st1);
            rows[j][0] = st4;
            String name = rs.getString(2);
            rows[j][1] = name;
            rows[j][3] = rs.getString(3);
            try {
                stmt1 = MdiWindow.con.createStatement(rs1.TYPE_SCROLL_INSENSITIVE, rs1.CONCUR_UPDATABLE);
                String sql = "select ename from employeeinfo where eid='" + name + "'";
                rs1 = stmt1.executeQuery(sql);
                while (rs1.next()) {
                    rows[j][2] = rs1.getString(1);
                    break;
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "All Query", 0);
            }
        }
        jTable1 = new JTable(rows, columns);
        jTable1.setRowHeight(30);
        jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        jTable1.setShowVerticalLines(true);
        jTable1.setShowHorizontalLines(true);
        jTable1.setShowGrid(true);
        jTable1.setGridColor(Color.WHITE);
        jTable1.setForeground(Color.YELLOW.brighter());
        jTable1.setEnabled(false);
        jTable1.setSelectionBackground(Color.black);
        jTable1.setBackground(Color.BLACK);
        jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jTable1.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    public void mouseClicked(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseEntered(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseExited(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(false);
                    }
                });
        jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        TableColumn column = null;
        for (int i = 0; i < columns.length; i++) {
            column = jTable1.getColumnModel().getColumn(i);
            if (i == 2) {
                column.setPreferredWidth(348);
            } else {
                column.setPreferredWidth(300);
            }
        }
        jScrollPane1 = new JScrollPane(jTable1);
        jScrollPane1.setBounds(50, 13, 1250, 332);
        add(jScrollPane1);
    }

    public void atnDateRecord(String strc, String strc1, String eid) throws SQLException {
        count1 = 0;
        count2 = 0;
        String arg = strc;
        String arg1 = strc1;
        String empid = eid;
        String str = "select * from empattendance where cur_date between '" + arg + "' and '" + arg1 + "' and eid='" + empid + "' order by cur_date asc";
        rs = stmt.executeQuery(str);
        for (int i = 0; rs.next(); i++) {
            totalRows += 1;
        }

        rows = new Object[totalRows][columns.length];
        rs.beforeFirst();
        for (int j = 0; rs.next(); j++) {
            String st = String.valueOf(rs.getDate(1));
            String st1 = st.substring(0, 4);
            String st2 = st.substring(5, 7);
            String st3 = st.substring(8, 10);
            String st4 = st3.concat("-").concat(st2).concat("-").concat(st1);
            rows[j][0] = st4;
            String name = rs.getString(2);
            rows[j][1] = name;
            rows[j][3] = rs.getString(3);
            try {
                stmt1 = MdiWindow.con.createStatement(rs1.TYPE_SCROLL_INSENSITIVE, rs1.CONCUR_UPDATABLE);
                String sql = "select ename from employeeinfo where eid='" + name + "'";
                rs1 = stmt1.executeQuery(sql);
                while (rs1.next()) {
                    rows[j][2] = rs1.getString(1);
                    break;
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "All Query", 0);
            }
        }
        jTable1 = new JTable(rows, columns);
        jTable1.setRowHeight(30);
        jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        jTable1.setShowVerticalLines(true);
        jTable1.setShowHorizontalLines(true);
        jTable1.setGridColor(Color.WHITE);
        jTable1.setShowGrid(true);
        jTable1.setForeground(Color.YELLOW.brighter());
        jTable1.setEnabled(false);
        jTable1.setSelectionBackground(Color.black);
        jTable1.setBackground(Color.BLACK);
        jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jTable1.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    public void mouseClicked(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseEntered(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseExited(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(false);
                    }
                });
        jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        TableColumn column = null;
        for (int i = 0; i < columns.length; i++) {
            column = jTable1.getColumnModel().getColumn(i);
            if (i == 2) {
                column.setPreferredWidth(348);
            } else {
                column.setPreferredWidth(300);
            }
        }
        jScrollPane1 = new JScrollPane(jTable1);
        jScrollPane1.setBounds(50, 13, 1250, 332);
        add(jScrollPane1);
        String sql = "select atn_mode from empattendance where eid='" + empid + "'";
        rs = stmt.executeQuery(sql);
        while (rs.next()) {
            String count = rs.getString(1);
            if (count.equals("Present")) {
                count1++;
            } else if (count.equals("Absent")) {
                count2++;
            }
        }
    }

    public void desAllRecord() throws SQLException {
        String str = "select * from designation order by des_id";
        rs = stmt.executeQuery(str);
        for (int i = 0; rs.next(); i++) {
            totalRows += 1;
        }
        rows = new Object[totalRows][columns1.length];
        rs.beforeFirst();
        for (int j = 0; rs.next(); j++) {
            rows[j][0] = rs.getString(1);
            rows[j][1] = rs.getString(2);
            rows[j][2] = rs.getString(3);
            rows[j][3] = rs.getString(4);
            rows[j][4] = rs.getString(5);
            rows[j][5] = rs.getString(6);
            rows[j][6] = rs.getString(7);
            rows[j][7] = rs.getString(8);
            rows[j][8] = rs.getString(9);
            rows[j][9] = rs.getString(10);
        }
        jTable1 = new JTable(rows, columns1);
        jTable1.setRowHeight(30);
        jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        jTable1.setShowVerticalLines(true);
        jTable1.setShowHorizontalLines(true);
        jTable1.setGridColor(Color.WHITE);
        jTable1.setShowGrid(true);
        jTable1.setForeground(Color.YELLOW.brighter());
        jTable1.setEnabled(false);
        jTable1.setSelectionBackground(Color.black);
        jTable1.setBackground(Color.BLACK);
        jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jTable1.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    public void mouseClicked(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseEntered(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseExited(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(false);
                    }
                });
        jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        TableColumn column = null;
        for (int i = 0; i < columns1.length; i++) {
            column = jTable1.getColumnModel().getColumn(i);
            if (i == 0 || i == 1) {
                column.setPreferredWidth(150);
            } else {
                column.setPreferredWidth(132);
            }
        }
        jScrollPane1 = new JScrollPane(jTable1);
        jScrollPane1.setBounds(50, 8, 1250, 332);
        add(jScrollPane1);
    }

    public void desIdRecord(String str) throws SQLException {
        String arg = str;
        String str1 = "select * from designation where des_id='" + arg + "'";
        rs = stmt.executeQuery(str1);
        for (int i = 0; rs.next(); i++) {
            totalRows += 1;
        }

        rows = new Object[totalRows][columns1.length];
        rs.beforeFirst();
        for (int j = 0; rs.next(); j++) {
            rows[j][0] = rs.getString(1);
            rows[j][1] = rs.getString(2);
            rows[j][2] = rs.getString(3);
            rows[j][3] = rs.getString(4);
            rows[j][4] = rs.getString(5);
            rows[j][5] = rs.getString(6);
            rows[j][6] = rs.getString(7);
            rows[j][7] = rs.getString(8);
            rows[j][8] = rs.getString(9);
            rows[j][9] = rs.getString(10);
        }
        jTable1 = new JTable(rows, columns1);
        jTable1.setRowHeight(30);
        jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        jTable1.setShowVerticalLines(true);
        jTable1.setShowHorizontalLines(true);
        jTable1.setGridColor(Color.WHITE);
        jTable1.setShowGrid(true);
        jTable1.setForeground(Color.YELLOW.brighter());
        jTable1.setEnabled(false);
        jTable1.setSelectionBackground(Color.black);
        jTable1.setBackground(Color.BLACK);
        jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jTable1.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    public void mouseClicked(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseEntered(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseExited(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(false);
                    }
                });
        jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        TableColumn column = null;
        for (int i = 0; i < columns1.length; i++) {
            column = jTable1.getColumnModel().getColumn(i);
            if (i == 0 || i == 1) {
                column.setPreferredWidth(150);
            } else {
                column.setPreferredWidth(132);
            }
        }
        jScrollPane1 = new JScrollPane(jTable1);
        jScrollPane1.setBounds(50, 8, 1250, 332);
        add(jScrollPane1);

    }

    public void desNameRecord(String str) throws SQLException {
        String arg = str;
        String str1 = "select * from designation where dname='" + arg + "' order by des_id";
        rs = stmt.executeQuery(str1);
        for (int i = 0; rs.next(); i++) {
            totalRows += 1;
        }
        rows = new Object[totalRows][columns1.length];
        rs.beforeFirst();
        for (int j = 0; rs.next(); j++) {
            rows[j][0] = rs.getString(1);
            rows[j][1] = rs.getString(2);
            rows[j][2] = rs.getString(3);
            rows[j][3] = rs.getString(4);
            rows[j][4] = rs.getString(5);
            rows[j][5] = rs.getString(6);
            rows[j][6] = rs.getString(7);
            rows[j][7] = rs.getString(8);
            rows[j][8] = rs.getString(9);
            rows[j][9] = rs.getString(10);
        }
        jTable1 = new JTable(rows, columns1);
        jTable1.setRowHeight(30);
        jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        jTable1.setShowVerticalLines(true);
        jTable1.setShowHorizontalLines(true);
        jTable1.setGridColor(Color.WHITE);
        jTable1.setShowGrid(true);
        jTable1.setForeground(Color.YELLOW.brighter());
        jTable1.setEnabled(false);
        jTable1.setSelectionBackground(Color.black);
        jTable1.setBackground(Color.BLACK);
        jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jTable1.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    public void mouseClicked(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseEntered(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseExited(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(false);
                    }
                });
        jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        TableColumn column = null;
        for (int i = 0; i < columns1.length; i++) {
            column = jTable1.getColumnModel().getColumn(i);
            if (i == 0 || i == 1) {
                column.setPreferredWidth(150);
            } else {
                column.setPreferredWidth(132);
            }
        }
        jScrollPane1 = new JScrollPane(jTable1);
        jScrollPane1.setBounds(50, 8, 1250, 332);
        add(jScrollPane1);
    }

    public void empAllRecord() throws SQLException {
        String str = "select * from employeeinfo order by eid";
        rs = stmt.executeQuery(str);
        for (int i = 0; rs.next(); i++) {
            totalRows += 1;
        }

        rows = new Object[totalRows][columns2.length];
        rs.beforeFirst();
        for (int j = 0; rs.next(); j++) {
            String sts = String.valueOf(rs.getDate(5));
            String sts1 = sts.substring(0, 4);
            String sts2 = sts.substring(5, 7);
            String sts3 = sts.substring(8, 10);
            String st4 = sts3.concat("-").concat(sts2).concat("-").concat(sts1);
            String std = String.valueOf(rs.getDate(6));
            String std1 = std.substring(0, 4);
            String std2 = std.substring(5, 7);
            String std3 = std.substring(8, 10);
            String std4 = std3.concat("-").concat(std2).concat("-").concat(std1);
            rows[j][0] = rs.getString(1);
            rows[j][1] = rs.getString(2);
            sesc = rs.getString(3);
            rows[j][2] = rs.getString(3);
            rows[j][3] = rs.getString(4);
            rows[j][4] = st4;
            rows[j][5] = std4;
            rows[j][6] = rs.getString(7);
            rows[j][7] = rs.getString(8);
            rows[j][8] = rs.getString(9);
            try {
                stmt1 = MdiWindow.con.createStatement(rs1.TYPE_SCROLL_INSENSITIVE, rs1.CONCUR_UPDATABLE);
                String st = "select dname from designation where des_id='" + sesc + "'";
                rs1 = stmt1.executeQuery(st);
                while (rs1.next()) {
                    rows[j][9] = rs1.getString(1);
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, ex.toString());
            }
        }
        jTable1 = new JTable(rows, columns2);
        jTable1.setRowHeight(30);
        jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        jTable1.setShowVerticalLines(true);
        jTable1.setShowHorizontalLines(true);
        jTable1.setGridColor(Color.WHITE);
        jTable1.setShowGrid(true);
        jTable1.setForeground(Color.YELLOW.brighter());
        jTable1.setEnabled(false);
        jTable1.setSelectionBackground(Color.black);
        jTable1.setBackground(Color.BLACK);
        jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jTable1.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    public void mouseClicked(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseEntered(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseExited(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(false);
                    }
                });
        jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        TableColumn column = null;
        for (int i = 0; i < columns2.length; i++) {
            column = jTable1.getColumnModel().getColumn(i);
            if (i == 0 || i == 2) {
                column.setPreferredWidth(100);
            } else if (i == 1) {
                column.setPreferredWidth(250);
            } else if (i == 3) {
                column.setPreferredWidth(200);
            } else if (i == 4) {
                column.setPreferredWidth(140);
            } else if (i == 5 || i == 9) {
                column.setPreferredWidth(125);
            } else if (i == 6 || i == 8) {
                column.setPreferredWidth(150);
            } else {
                column.setPreferredWidth(290);
            }
        }
        jScrollPane1 = new JScrollPane(jTable1);
        jScrollPane1.setBounds(50, 15, 1250, 320);
        add(jScrollPane1);
    }

    public void empIdRecord(String str) throws SQLException {
        String arg = str;
        String str1 = "select * from employeeinfo where eid='" + arg + "' order by eid";
        rs = stmt.executeQuery(str1);
        for (int i = 0; rs.next(); i++) {
            totalRows += 1;
        }

        rows = new Object[totalRows][columns2.length];
        rs.beforeFirst();
        for (int j = 0; rs.next(); j++) {
            String sts = String.valueOf(rs.getDate(5));
            String sts1 = sts.substring(0, 4);
            String sts2 = sts.substring(5, 7);
            String sts3 = sts.substring(8, 10);
            String st4 = sts3.concat("-").concat(sts2).concat("-").concat(sts1);
            String std = String.valueOf(rs.getDate(6));
            String std1 = std.substring(0, 4);
            String std2 = std.substring(5, 7);
            String std3 = std.substring(8, 10);
            String std4 = std3.concat("-").concat(std2).concat("-").concat(std1);
            rows[j][0] = rs.getString(1);
            rows[j][1] = rs.getString(2);
            sesc = rs.getString(3);
            rows[j][2] = rs.getString(3);
            rows[j][3] = rs.getString(4);
            rows[j][4] = st4;
            rows[j][5] = std4;
            rows[j][6] = rs.getString(7);
            rows[j][7] = rs.getString(8);
            rows[j][8] = rs.getString(9);
            try {
                stmt1 = MdiWindow.con.createStatement(rs1.TYPE_SCROLL_INSENSITIVE, rs1.CONCUR_UPDATABLE);
                String st = "select dname from designation where des_id='" + sesc + "'";
                rs1 = stmt1.executeQuery(st);
                while (rs1.next()) {
                    rows[j][9] = rs1.getString(1);
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, ex.toString());
            }
        }
        jTable1 = new JTable(rows, columns2);
        jTable1.setRowHeight(30);
        jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        jTable1.setShowVerticalLines(true);
        jTable1.setShowHorizontalLines(true);
        jTable1.setGridColor(Color.WHITE);
        jTable1.setShowGrid(true);
        jTable1.setForeground(Color.YELLOW.brighter());
        jTable1.setEnabled(false);
        jTable1.setSelectionBackground(Color.black);
        jTable1.setBackground(Color.BLACK);
        jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jTable1.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    public void mouseClicked(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseEntered(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseExited(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(false);
                    }
                });
        jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        TableColumn column = null;
        for (int i = 0; i < columns2.length; i++) {
            column = jTable1.getColumnModel().getColumn(i);
            if (i == 0 || i == 2) {
                column.setPreferredWidth(100);
            } else if (i == 1) {
                column.setPreferredWidth(250);
            } else if (i == 3) {
                column.setPreferredWidth(200);
            } else if (i == 4) {
                column.setPreferredWidth(140);
            } else if (i == 5 || i == 9) {
                column.setPreferredWidth(125);
            } else if (i == 6 || i == 8) {
                column.setPreferredWidth(150);
            } else {
                column.setPreferredWidth(290);
            }
        }
        jScrollPane1 = new JScrollPane(jTable1);
        jScrollPane1.setBounds(50, 15, 1250, 320);
        add(jScrollPane1);
    }

    public void empNameRecord(String str) throws SQLException {
        String arg = str;
        String str1 = "select * from employeeinfo where ename='" + arg + "' order by eid";
        rs = stmt.executeQuery(str1);
        for (int i = 0; rs.next(); i++) {
            totalRows += 1;
        }
        rows = new Object[totalRows][columns2.length];
        rs.beforeFirst();
        for (int j = 0; rs.next(); j++) {
            String sts = String.valueOf(rs.getDate(5));
            String sts1 = sts.substring(0, 4);
            String sts2 = sts.substring(5, 7);
            String sts3 = sts.substring(8, 10);
            String st4 = sts3.concat("-").concat(sts2).concat("-").concat(sts1);
            String std = String.valueOf(rs.getDate(6));
            String std1 = std.substring(0, 4);
            String std2 = std.substring(5, 7);
            String std3 = std.substring(8, 10);
            String std4 = std3.concat("-").concat(std2).concat("-").concat(std1);
            rows[j][0] = rs.getString(1);
            rows[j][1] = rs.getString(2);
            sesc = rs.getString(3);
            rows[j][2] = rs.getString(3);
            rows[j][3] = rs.getString(4);
            rows[j][4] = st4;
            rows[j][5] = std4;
            rows[j][6] = rs.getString(7);
            rows[j][7] = rs.getString(8);
            rows[j][8] = rs.getString(9);
            try {

                stmt1 = MdiWindow.con.createStatement(rs1.TYPE_SCROLL_INSENSITIVE, rs1.CONCUR_UPDATABLE);
                String st = "select dname from designation where des_id='" + sesc + "'";
                rs1 = stmt1.executeQuery(st);
                while (rs1.next()) {
                    rows[j][9] = rs1.getString(1);
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, ex.toString());
            }
        }
        jTable1 = new JTable(rows, columns2);
        jTable1.setRowHeight(30);
        jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        jTable1.setShowVerticalLines(true);
        jTable1.setShowHorizontalLines(true);
        jTable1.setGridColor(Color.WHITE);
        jTable1.setShowGrid(true);
        jTable1.setForeground(Color.YELLOW.brighter());
        jTable1.setEnabled(false);
        jTable1.setSelectionBackground(Color.black);
        jTable1.setBackground(Color.BLACK);
        jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jTable1.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    public void mouseClicked(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseEntered(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseExited(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(false);
                    }
                });
        jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        TableColumn column = null;
        for (int i = 0; i < columns2.length; i++) {
            column = jTable1.getColumnModel().getColumn(i);
            if (i == 0 || i == 2) {
                column.setPreferredWidth(100);
            } else if (i == 1) {
                column.setPreferredWidth(250);
            } else if (i == 3) {
                column.setPreferredWidth(200);
            } else if (i == 4) {
                column.setPreferredWidth(140);
            } else if (i == 5 || i == 9) {
                column.setPreferredWidth(125);
            } else if (i == 6 || i == 8) {
                column.setPreferredWidth(150);
            } else {
                column.setPreferredWidth(290);
            }
        }
        jScrollPane1 = new JScrollPane(jTable1);
        jScrollPane1.setBounds(50, 15, 1250, 320);
        add(jScrollPane1);
    }

    public void empPostRecord(String str) {
        String st1 = str;
        String st2 = "";
        String st3 = "";
        String st = "";
        try {
            st = "select des_id from employeeinfo";
            rs = stmt.executeQuery(st);
            while (rs.next()) {
                st2 = rs.getString(1);
                try {
                    stmt1 = MdiWindow.con.createStatement(rs1.TYPE_SCROLL_INSENSITIVE, rs1.CONCUR_UPDATABLE);
                    String sta = "select des_id from designation where dname='" + st1 + "'";
                    rs1 = stmt1.executeQuery(sta);
                    while (rs1.next()) {
                        st3 = rs1.getString(1);
                        if (st2.equalsIgnoreCase(st3)) {
                            totalRows += 1;
                            flag = true;
                            break;
                        }
                    }
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(this, ex.toString());
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, ex.toString());
        }
        if (flag == true) {
            rows = new Object[totalRows][columns2.length];
            try {
                stmt2 = MdiWindow.con.createStatement(rs2.TYPE_SCROLL_INSENSITIVE, rs2.CONCUR_UPDATABLE);
                String str1 = "select * from employeeinfo where des_id='" + st3 + "'";
                rs2 = stmt2.executeQuery(str1);
                rs2.beforeFirst();
                for (int j = 0; rs2.next(); j++) {
                    rows[j][0] = rs2.getString(1);
                    rows[j][1] = rs2.getString(2);
                    rows[j][2] = rs2.getString(3);
                    rows[j][3] = rs2.getString(4);
                    String sts = String.valueOf(rs2.getDate(5));
                    String sts1 = sts.substring(0, 4);
                    String sts2 = sts.substring(5, 7);
                    String sts3 = sts.substring(8, 10);
                    String st4 = sts3.concat("-").concat(sts2).concat("-").concat(sts1);
                    String std = String.valueOf(rs2.getDate(6));
                    String std1 = std.substring(0, 4);
                    String std2 = std.substring(5, 7);
                    String std3 = std.substring(8, 10);
                    String std4 = std3.concat("-").concat(std2).concat("-").concat(std1);
                    rows[j][4] = st4;
                    rows[j][5] = std4;
                    rows[j][6] = rs2.getString(7);
                    rows[j][7] = rs2.getString(8);
                    rows[j][8] = rs2.getString(9);
                    rows[j][9] = st1;
                }
                jTable1 = new JTable(rows, columns2);
                jTable1.setRowHeight(30);
                jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
                jTable1.setShowVerticalLines(true);
                jTable1.setShowHorizontalLines(true);
                jTable1.setGridColor(Color.WHITE);
                jTable1.setShowGrid(true);
                jTable1.setForeground(Color.YELLOW.brighter());
                jTable1.setEnabled(false);
                jTable1.setSelectionBackground(Color.black);
                jTable1.setBackground(Color.BLACK);
                jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
                jTable1.addMouseListener(
                        new java.awt.event.MouseAdapter() {

                            public void mouseClicked(java.awt.event.MouseEvent m) {
                                jTable1.setRowSelectionAllowed(true);
                            }

                            public void mouseEntered(java.awt.event.MouseEvent m) {
                                jTable1.setRowSelectionAllowed(true);
                            }

                            public void mouseExited(java.awt.event.MouseEvent m) {
                                jTable1.setRowSelectionAllowed(false);
                            }
                        });
                jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
                TableColumn column = null;
                for (int i = 0; i < columns2.length; i++) {
                    column = jTable1.getColumnModel().getColumn(i);
                    if (i == 0 || i == 2) {
                        column.setPreferredWidth(100);
                    } else if (i == 1) {
                        column.setPreferredWidth(250);
                    } else if (i == 3) {
                        column.setPreferredWidth(200);
                    } else if (i == 4) {
                        column.setPreferredWidth(140);
                    } else if (i == 5 || i == 9) {
                        column.setPreferredWidth(125);
                    } else if (i == 6 || i == 8) {
                        column.setPreferredWidth(150);
                    } else {
                        column.setPreferredWidth(290);
                    }
                }
                jScrollPane1 = new JScrollPane(jTable1);
                jScrollPane1.setBounds(50, 15, 1250, 320);
                add(jScrollPane1);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, ex.toString());
            }
        }
    }

    public void leaveAllRecord() throws SQLException {
        String str = "";
        str = "select * from leave order by lno";
        rs = stmt.executeQuery(str);
        for (int i = 0; rs.next(); i++) {
            totalRows += 1;
        }

        rows = new Object[totalRows][columns3.length];
        rs.beforeFirst();
        for (int j = 0; rs.next(); j++) {
            String st = String.valueOf(rs.getDate(4));
            String st1 = st.substring(0, 4);
            String st2 = st.substring(5, 7);
            String st3 = st.substring(8, 10);
            String st4 = st3.concat("-").concat(st2).concat("-").concat(st1);
            String std = String.valueOf(rs.getDate(5));
            String std1 = std.substring(0, 4);
            String std2 = std.substring(5, 7);
            String std3 = std.substring(8, 10);
            String std4 = std3.concat("-").concat(std2).concat("-").concat(std1);
            rows[j][0] = rs.getString(1);
            rows[j][1] = rs.getString(2);
            rows[j][2] = rs.getString(3);
            rows[j][3] = st4;
            rows[j][4] = std4;
            rows[j][5] = rs.getString(6);
        }
        jTable1 = new JTable(rows, columns3);
        jTable1.setRowHeight(30);
        jTable1.setSelectionForeground(Color.YELLOW.brighter());
        jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        jTable1.setShowVerticalLines(true);
        jTable1.setShowHorizontalLines(true);
        jTable1.setGridColor(Color.WHITE);
        jTable1.setShowGrid(true);
        jTable1.setForeground(Color.YELLOW.brighter());
        jTable1.setEnabled(false);
        jTable1.setSelectionBackground(Color.black);
        jTable1.setBackground(Color.BLACK);
        jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jTable1.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    public void mouseClicked(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseEntered(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseExited(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(false);
                    }
                });
        jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        TableColumn column = null;
        for (int i = 0; i < columns3.length; i++) {
            column = jTable1.getColumnModel().getColumn(i);
            if (i == 3 || i == 4 || i == 2) {
                column.setPreferredWidth(260);
            } else if (i == 5) {
                column.setPreferredWidth(168);
            } else {
                column.setPreferredWidth(150);
            }
        }
        jScrollPane1 = new JScrollPane(jTable1);
        jScrollPane1.setBounds(50, 24, 1250, 360);
        add(jScrollPane1);
    }

    public void leaveIdRecord(String str) throws SQLException {
        String arg = str;
        String str1 = "select * from leave where eid='" + arg + "'order by lno";
        rs = stmt.executeQuery(str1);
        for (int i = 0; rs.next(); i++) {
            totalRows += 1;
        }

        rows = new Object[totalRows][columns3.length];
        rs.beforeFirst();
        for (int j = 0; rs.next(); j++) {
            String st = String.valueOf(rs.getDate(4));
            String st1 = st.substring(0, 4);
            String st2 = st.substring(5, 7);
            String st3 = st.substring(8, 10);
            String st4 = st3.concat("-").concat(st2).concat("-").concat(st1);
            String std = String.valueOf(rs.getDate(5));
            String std1 = std.substring(0, 4);
            String std2 = std.substring(5, 7);
            String std3 = std.substring(8, 10);
            String std4 = std3.concat("-").concat(std2).concat("-").concat(std1);
            rows[j][0] = rs.getString(1);
            rows[j][1] = rs.getString(2);
            rows[j][2] = rs.getString(3);
            rows[j][3] = st4;
            rows[j][4] = std4;
            rows[j][5] = rs.getString(6);
        }
        jTable1 = new JTable(rows, columns3);
        jTable1.setRowHeight(30);
        jTable1.setSelectionForeground(Color.YELLOW.brighter());
        jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        jTable1.setShowVerticalLines(true);
        jTable1.setShowHorizontalLines(true);
        jTable1.setGridColor(Color.WHITE);
        jTable1.setShowGrid(true);
        jTable1.setForeground(Color.YELLOW.brighter());
        jTable1.setEnabled(false);
        jTable1.setSelectionBackground(Color.black);
        jTable1.setBackground(Color.BLACK);
        jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jTable1.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    public void mouseClicked(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseEntered(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseExited(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(false);
                    }
                });
        jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        TableColumn column = null;
        for (int i = 0; i < columns3.length; i++) {
            column = jTable1.getColumnModel().getColumn(i);
            if (i == 3 || i == 4 || i == 2) {
                column.setPreferredWidth(260);
            } else if (i == 5) {
                column.setPreferredWidth(168);
            } else {
                column.setPreferredWidth(150);
            }
        }
        jScrollPane1 = new JScrollPane(jTable1);
        jScrollPane1.setBounds(50, 24, 1250, 360);
        add(jScrollPane1);
    }

    public void loanAllRecord() throws SQLException {
        String str = "select * from loan order by lid";
        rs = stmt.executeQuery(str);
        for (int i = 0; rs.next(); i++) {
            totalRows += 1;
        }

        rows = new Object[totalRows][columns4.length];
        rs.beforeFirst();
        for (int j = 0; rs.next(); j++) {
            String st = String.valueOf(rs.getDate(3));
            String st1 = st.substring(0, 4);
            String st2 = st.substring(5, 7);
            String st3 = st.substring(8, 10);
            String st4 = st3.concat("-").concat(st2).concat("-").concat(st1);
            rows[j][0] = rs.getString(1);
            rows[j][1] = rs.getString(2);
            rows[j][2] = st4;
            rows[j][3] = rs.getString(4);
            rows[j][4] = rs.getString(7);
            rows[j][5] = rs.getString(8);
            rows[j][6] = rs.getString(9);
            rows[j][7] = rs.getString(5);
            rows[j][8] = rs.getString(6);
        }
        jTable1 = new JTable(rows, columns4);
        jTable1.setRowHeight(30);
        jTable1.setSelectionForeground(Color.YELLOW.brighter());
        jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        jTable1.setShowVerticalLines(true);
        jTable1.setShowHorizontalLines(true);
        jTable1.setGridColor(Color.WHITE);
        jTable1.setShowGrid(true);
        jTable1.setForeground(Color.YELLOW.brighter());
        jTable1.setEnabled(false);
        jTable1.setSelectionBackground(Color.black);
        jTable1.setBackground(Color.BLACK);
        jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jTable1.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    public void mouseClicked(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseEntered(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseExited(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(false);
                    }
                });
        jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        TableColumn column = null;
        for (int i = 0; i < columns4.length; i++) {
            column = jTable1.getColumnModel().getColumn(i);
            if (i == 0) {
                column.setPreferredWidth(200);
            } else if (i == 1 || i == 5 || i == 3 || i == 4 || i == 6 || i == 8) {
                column.setPreferredWidth(179);
            } else if (i == 2) {
                column.setPreferredWidth(220);
            } else {
                column.setPreferredWidth(250);
            }
        }
        jScrollPane1 = new JScrollPane(jTable1);
        jScrollPane1.setBounds(50, 33, 1250, 355);
        add(jScrollPane1);
    }

    public void loanIdRecord(String str) throws SQLException {
        String arg = str;
        String str1 = "select * from loan where eid='" + arg + "'order by lid";
        rs = stmt.executeQuery(str1);
        for (int i = 0; rs.next(); i++) {
            totalRows += 1;
        }

        rows = new Object[totalRows][columns4.length];
        rs.beforeFirst();
        for (int j = 0; rs.next(); j++) {
            String st = String.valueOf(rs.getDate(3));
            String st1 = st.substring(0, 4);
            String st2 = st.substring(5, 7);
            String st3 = st.substring(8, 10);
            String st4 = st3.concat("-").concat(st2).concat("-").concat(st1);
            rows[j][0] = rs.getString(1);
            rows[j][1] = rs.getString(2);
            rows[j][2] = st4;
            rows[j][3] = rs.getString(4);
            rows[j][4] = rs.getString(7);
            rows[j][5] = rs.getString(8);
            rows[j][6] = rs.getString(9);
            rows[j][7] = rs.getString(5);
            rows[j][8] = rs.getString(6);
        }
        jTable1 = new JTable(rows, columns4);
        jTable1.setRowHeight(30);
        jTable1.setSelectionForeground(Color.YELLOW.brighter());
        jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        jTable1.setShowVerticalLines(true);
        jTable1.setShowHorizontalLines(true);
        jTable1.setGridColor(Color.WHITE);
        jTable1.setShowGrid(true);
        jTable1.setForeground(Color.YELLOW.brighter());
        jTable1.setEnabled(false);
        jTable1.setSelectionBackground(Color.black);
        jTable1.setBackground(Color.BLACK);
        jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jTable1.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    public void mouseClicked(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseEntered(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseExited(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(false);
                    }
                });
        jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        TableColumn column = null;
        for (int i = 0; i < columns4.length; i++) {
            column = jTable1.getColumnModel().getColumn(i);
            if (i == 0) {
                column.setPreferredWidth(200);
            } else if (i == 1 || i == 5 || i == 3 || i == 4 || i == 6 || i == 8) {
                column.setPreferredWidth(179);
            } else if (i == 2) {
                column.setPreferredWidth(220);
            } else {
                column.setPreferredWidth(250);
            }
        }
        jScrollPane1 = new JScrollPane(jTable1);
        jScrollPane1.setBounds(50, 33, 1250, 355);
        add(jScrollPane1);
    }

    public void salAllRecord() throws SQLException {
        String str = "";
        str = "select * from salary order by eid";
        rs = stmt.executeQuery(str);
        for (int i = 0; rs.next(); i++) {
            totalRows += 1;
        }

        rows = new Object[totalRows][columns5.length];
        rs.beforeFirst();
        for (int j = 0; rs.next(); j++) {
            String st = String.valueOf(rs.getDate(6));
            String st1 = st.substring(0, 4);
            String st2 = st.substring(5, 7);
            String st3 = st.substring(8, 10);
            String st4 = st3.concat("-").concat(st2).concat("-").concat(st1);
            rows[j][0] = rs.getString(1);
            rows[j][1] = rs.getString(2);
            rows[j][2] = rs.getString(3);
            rows[j][3] = rs.getString(4);
            rows[j][4] = rs.getString(5);
            rows[j][5] = st4;
            rows[j][6] = rs.getString(7);
        }
        jTable1 = new JTable(rows, columns5);
        jTable1.setRowHeight(30);
        jTable1.setSelectionForeground(Color.YELLOW.brighter());
        jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        jTable1.setShowVerticalLines(true);
        jTable1.setShowHorizontalLines(true);
        jTable1.setGridColor(Color.WHITE);
        jTable1.setShowGrid(true);
        jTable1.setForeground(Color.YELLOW.brighter());
        jTable1.setEnabled(false);
        jTable1.setSelectionBackground(Color.black);
        jTable1.setBackground(Color.BLACK);
        jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jTable1.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    public void mouseClicked(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseEntered(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseExited(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(false);
                    }
                });
        jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        TableColumn column = null;
        for (int i = 0; i < columns5.length; i++) {
            column = jTable1.getColumnModel().getColumn(i);
            if (i == 6) {
                column.setPreferredWidth(150);
            } else {
                column.setPreferredWidth(200);
            }
        }
        jScrollPane1 = new JScrollPane(jTable1);
        jScrollPane1.setBounds(50, 22, 1250, 297);
        add(jScrollPane1);
    }

    public void salIdRecord(String str) throws SQLException {
        String arg = str;
        String str1 = "select * from salary where eid='" + arg + "' order by eid";
        rs = stmt.executeQuery(str1);
        for (int i = 0; rs.next(); i++) {
            totalRows += 1;
        }

        rows = new Object[totalRows][columns5.length];
        rs.beforeFirst();
        for (int j = 0; rs.next(); j++) {
            String st = String.valueOf(rs.getDate(6));
            String st1 = st.substring(0, 4);
            String st2 = st.substring(5, 7);
            String st3 = st.substring(8, 10);
            String st4 = st3.concat("-").concat(st2).concat("-").concat(st1);
            rows[j][0] = rs.getString(1);
            rows[j][1] = rs.getString(2);
            rows[j][2] = rs.getString(3);
            rows[j][3] = rs.getString(4);
            rows[j][4] = rs.getString(5);
            rows[j][5] = st4;
            rows[j][6] = rs.getString(7);
        }
        jTable1 = new JTable(rows, columns5);
        jTable1.setRowHeight(30);
        jTable1.setSelectionForeground(Color.YELLOW.brighter());
        jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        jTable1.setShowVerticalLines(true);
        jTable1.setShowHorizontalLines(true);
        jTable1.setGridColor(Color.WHITE);
        jTable1.setShowGrid(true);
        jTable1.setForeground(Color.YELLOW.brighter());
        jTable1.setEnabled(false);
        jTable1.setSelectionBackground(Color.black);
        jTable1.setBackground(Color.BLACK);
        jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jTable1.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    public void mouseClicked(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseEntered(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseExited(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(false);
                    }
                });
        jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        TableColumn column = null;
        for (int i = 0; i < columns5.length; i++) {
            column = jTable1.getColumnModel().getColumn(i);
            if (i == 6) {
                column.setPreferredWidth(150);
            } else {
                column.setPreferredWidth(200);
            }
        }
        jScrollPane1 = new JScrollPane(jTable1);
        jScrollPane1.setBounds(50, 22, 1250, 297);
        add(jScrollPane1);
    }

    public void salSDateRecord(String str) throws SQLException {
        String arg = str;
        String str1 = "select * from salary where sal_date='" + arg + "' order by sal_date desc";
        rs = stmt.executeQuery(str1);
        for (int i = 0; rs.next(); i++) {
            totalRows += 1;
        }

        rows = new Object[totalRows][columns5.length];
        rs.beforeFirst();
        for (int j = 0; rs.next(); j++) {
            String st = String.valueOf(rs.getDate(6));
            String st1 = st.substring(0, 4);
            String st2 = st.substring(5, 7);
            String st3 = st.substring(8, 10);
            String st4 = st3.concat("-").concat(st2).concat("-").concat(st1);
            rows[j][0] = rs.getString(1);
            rows[j][1] = rs.getString(2);
            rows[j][2] = rs.getString(3);
            rows[j][3] = rs.getString(4);
            rows[j][4] = rs.getString(5);
            rows[j][5] = st4;
            rows[j][6] = rs.getString(7);
        }
        jTable1 = new JTable(rows, columns5);
        jTable1.setRowHeight(30);
        jTable1.setSelectionForeground(Color.YELLOW.brighter());
        jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        jTable1.setShowVerticalLines(true);
        jTable1.setShowHorizontalLines(true);
        jTable1.setGridColor(Color.WHITE);
        jTable1.setShowGrid(true);
        jTable1.setForeground(Color.YELLOW.brighter());
        jTable1.setEnabled(false);
        jTable1.setSelectionBackground(Color.black);
        jTable1.setBackground(Color.BLACK);
        jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jTable1.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    public void mouseClicked(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseEntered(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseExited(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(false);
                    }
                });
        jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        TableColumn column = null;
        for (int i = 0; i < columns5.length; i++) {
            column = jTable1.getColumnModel().getColumn(i);
            if (i == 6) {
                column.setPreferredWidth(150);
            } else {
                column.setPreferredWidth(200);
            }
        }
        jScrollPane1 = new JScrollPane(jTable1);
        jScrollPane1.setBounds(50, 22, 1250, 297);
        add(jScrollPane1);
    }

    public void salDateBetweenRecord(String str, String str1) throws SQLException {
        String arg1 = str;
        String stc1 = str1;
        String str2 = "select * from salary where sal_date between '" + arg1 + "' and '" + stc1 + "' order by sal_date asc";
        rs = stmt.executeQuery(str2);
        for (int i = 0; rs.next(); i++) {
            totalRows += 1;
        }

        rows = new Object[totalRows][columns5.length];
        rs.beforeFirst();
        for (int j = 0; rs.next(); j++) {
            String st = String.valueOf(rs.getDate(6));
            String st1 = st.substring(0, 4);
            String st2 = st.substring(5, 7);
            String st3 = st.substring(8, 10);
            String st4 = st3.concat("-").concat(st2).concat("-").concat(st1);
            rows[j][0] = rs.getString(1);
            rows[j][1] = rs.getString(2);
            rows[j][2] = rs.getString(3);
            rows[j][3] = rs.getString(4);
            rows[j][4] = rs.getString(5);
            rows[j][5] = st4;
            rows[j][6] = rs.getString(7);
        }
        jTable1 = new JTable(rows, columns5);
        jTable1.setRowHeight(30);
        jTable1.setSelectionForeground(Color.YELLOW.brighter());
        jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        jTable1.setShowVerticalLines(true);
        jTable1.setShowHorizontalLines(true);
        jTable1.setGridColor(Color.WHITE);
        jTable1.setShowGrid(true);
        jTable1.setForeground(Color.YELLOW.brighter());
        jTable1.setEnabled(false);
        jTable1.setSelectionBackground(Color.black);
        jTable1.setBackground(Color.BLACK);
        jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jTable1.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    public void mouseClicked(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseEntered(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseExited(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(false);
                    }
                });
        jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        TableColumn column = null;
        for (int i = 0; i < columns5.length; i++) {
            column = jTable1.getColumnModel().getColumn(i);
            if (i == 6) {
                column.setPreferredWidth(150);
            } else {
                column.setPreferredWidth(200);
            }
        }
        jScrollPane1 = new JScrollPane(jTable1);
        jScrollPane1.setBounds(50, 22, 1250, 297);
        add(jScrollPane1);
    }

    public void loanPaymentAllRecord() throws SQLException {
        String str = "select * from loanpayment order by lid";
        rs = stmt.executeQuery(str);
        for (int i = 0; rs.next(); i++) {
            totalRows += 1;
        }

        rows = new Object[totalRows][columns6.length];//private String[] columns6={"LOAN ID","EMPLOYEE ID","LOAN PAYMENT DATE","PAY AMOUNT","CURRENT AMOUNT","REMAINING MONTH"};
        rs.beforeFirst();
        for (int j = 0; rs.next(); j++) {
            String st = String.valueOf(rs.getDate(2));
            String st1 = st.substring(0, 4);
            String st2 = st.substring(5, 7);
            String st3 = st.substring(8, 10);
            String st4 = st3.concat("-").concat(st2).concat("-").concat(st1);
            String lid = rs.getString(1);
            rows[j][0] = lid;
            rows[j][2] = st4;
            rows[j][3] = rs.getString(3);
            rows[j][4] = rs.getString(4);
            rows[j][5] = rs.getString(5);
            try {
                stmt1 = MdiWindow.con.createStatement(rs1.TYPE_SCROLL_INSENSITIVE, rs1.CONCUR_UPDATABLE);
                String sql = "select eid from loan where lid='" + lid + "'";
                rs1 = stmt1.executeQuery(sql);
                while (rs1.next()) {
                    rows[j][1] = rs1.getString(1);
                    break;
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Loan Payment Query", 0);
            }
        }
        jTable1 = new JTable(rows, columns6);
        jTable1.setRowHeight(30);
        jTable1.setSelectionForeground(Color.YELLOW.brighter());
        jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        jTable1.setShowVerticalLines(true);
        jTable1.setShowHorizontalLines(true);
        jTable1.setGridColor(Color.WHITE);
        jTable1.setShowGrid(true);
        jTable1.setForeground(Color.YELLOW.brighter());
        jTable1.setEnabled(false);
        jTable1.setSelectionBackground(Color.black);
        jTable1.setBackground(Color.BLACK);
        jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jTable1.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    public void mouseClicked(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseEntered(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseExited(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(false);
                    }
                });
        jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        TableColumn column = null;
        for (int i = 0; i < columns6.length; i++) {
            column = jTable1.getColumnModel().getColumn(i);
            if (i == 0) {
                column.setPreferredWidth(200);
            } else if (i == 1 || i == 3 || i == 4) {
                column.setPreferredWidth(210);
            } else if (i == 2) {
                column.setPreferredWidth(250);
            } else {
                column.setPreferredWidth(168);
            }
        }
        jScrollPane1 = new JScrollPane(jTable1);
        jScrollPane1.setBounds(50, 19, 1250, 320);
        add(jScrollPane1);
    }

    public void loanPaymentIdRecord(String str) throws SQLException {
        String arg = str;
        String lid = "";
        String str1 = "select lid from loan where eid='" + arg + "'order by lid";
        rs = stmt.executeQuery(str1);
        while (rs.next()) {
            lid = rs.getString(1);
            break;
        }
        String sql = "select * from loanpayment where lid='" + lid + "'";
        rs = stmt.executeQuery(sql);
        for (int i = 0; rs.next(); i++) {
            totalRows += 1;
        }

        rows = new Object[totalRows][columns6.length];//private String[] columns6={"LOAN ID","EMPLOYEE ID","LOAN PAYMENT DATE","PAY AMOUNT","CURRENT AMOUNT","REMAINING MONTH"};
        rs.beforeFirst();
        for (int j = 0; rs.next(); j++) {
            String st = String.valueOf(rs.getDate(2));
            String st1 = st.substring(0, 4);
            String st2 = st.substring(5, 7);
            String st3 = st.substring(8, 10);
            String st4 = st3.concat("-").concat(st2).concat("-").concat(st1);
            lid = rs.getString(1);
            rows[j][0] = lid;
            rows[j][2] = st4;
            rows[j][3] = rs.getString(3);
            rows[j][4] = rs.getString(4);
            rows[j][5] = rs.getString(5);
            try {
                stmt1 = MdiWindow.con.createStatement(rs1.TYPE_SCROLL_INSENSITIVE, rs1.CONCUR_UPDATABLE);
                String sql1 = "select eid from loan where lid='" + lid + "'";
                rs1 = stmt1.executeQuery(sql1);
                while (rs1.next()) {
                    rows[j][1] = rs1.getString(1);
                    break;
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Loan Payment Query", 0);
            }
        }
        jTable1 = new JTable(rows, columns6);
        jTable1.setRowHeight(30);
        jTable1.setSelectionForeground(Color.YELLOW.brighter());
        jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        jTable1.setShowVerticalLines(true);
        jTable1.setShowHorizontalLines(true);
        jTable1.setGridColor(Color.WHITE);
        jTable1.setShowGrid(true);
        jTable1.setForeground(Color.YELLOW.brighter());
        jTable1.setEnabled(false);
        jTable1.setSelectionBackground(Color.black);
        jTable1.setBackground(Color.BLACK);
        jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jTable1.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    public void mouseClicked(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseEntered(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseExited(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(false);
                    }
                });
        jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        TableColumn column = null;
        for (int i = 0; i < columns6.length; i++) {
            column = jTable1.getColumnModel().getColumn(i);
            if (i == 0) {
                column.setPreferredWidth(200);
            } else if (i == 1 || i == 3 || i == 4) {
                column.setPreferredWidth(210);
            } else if (i == 2) {
                column.setPreferredWidth(250);
            } else {
                column.setPreferredWidth(168);
            }
        }
        jScrollPane1 = new JScrollPane(jTable1);
        jScrollPane1.setBounds(50, 19, 1250, 320);
        add(jScrollPane1);
    }

    public void LoanPayDateRecord(String str) throws SQLException {
        String arg = str;
        String str1 = "select * from loanpayment where loanpay_date='" + arg + "' order by loanpay_date desc";
        rs = stmt.executeQuery(str1);
        for (int i = 0; rs.next(); i++) {
            totalRows += 1;
        }

        rows = new Object[totalRows][columns6.length];
        rs.beforeFirst();
        for (int j = 0; rs.next(); j++) {
            String st = String.valueOf(rs.getDate(2));
            String st1 = st.substring(0, 4);
            String st2 = st.substring(5, 7);
            String st3 = st.substring(8, 10);
            String st4 = st3.concat("-").concat(st2).concat("-").concat(st1);
            String lid = rs.getString(1);
            rows[j][0] = lid;
            rows[j][2] = st4;
            rows[j][3] = rs.getString(3);
            rows[j][4] = rs.getString(4);
            rows[j][5] = rs.getString(5);
            try {
                stmt1 = MdiWindow.con.createStatement(rs1.TYPE_SCROLL_INSENSITIVE, rs1.CONCUR_UPDATABLE);
                String sql1 = "select eid from loan where lid='" + lid + "'";
                rs1 = stmt1.executeQuery(sql1);
                while (rs1.next()) {
                    rows[j][1] = rs1.getString(1);
                    break;
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Loan Payment Query", 0);
            }
        }
        jTable1 = new JTable(rows, columns6);
        jTable1.setRowHeight(30);
        jTable1.setSelectionForeground(Color.YELLOW.brighter());
        jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        jTable1.setShowVerticalLines(true);
        jTable1.setShowHorizontalLines(true);
        jTable1.setGridColor(Color.WHITE);
        jTable1.setShowGrid(true);
        jTable1.setForeground(Color.YELLOW.brighter());
        jTable1.setEnabled(false);
        jTable1.setSelectionBackground(Color.black);
        jTable1.setBackground(Color.BLACK);
        jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jTable1.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    public void mouseClicked(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseEntered(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(true);
                    }

                    public void mouseExited(java.awt.event.MouseEvent m) {
                        jTable1.setRowSelectionAllowed(false);
                    }
                });
        jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        TableColumn column = null;
        for (int i = 0; i < columns6.length; i++) {
            column = jTable1.getColumnModel().getColumn(i);
            if (i == 0) {
                column.setPreferredWidth(200);
            } else if (i == 1 || i == 3 || i == 4) {
                column.setPreferredWidth(210);
            } else if (i == 2) {
                column.setPreferredWidth(250);
            } else {
                column.setPreferredWidth(168);
            }
        }
        jScrollPane1 = new JScrollPane(jTable1);
        jScrollPane1.setBounds(50, 19, 1250, 320);
        add(jScrollPane1);
    }
}
