/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package EmployeeInformation;

import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author ASIF
 */
public class ModifyAllUser extends javax.swing.JFrame {

    private Statement stmt, stmt1;
    private ResultSet rs, rs1;
    private int ctr = 1;
    private int total = 1;

    public ModifyAllUser() {
        initComponents();
        jPanel3.add(new NewUserPanel());
        try {
            stmt = MdiWindow.con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            String str = "select * from userlogin";
            rs = stmt.executeQuery(str);
            rs.first();
            jpwd1.setText(rs.getString(1));
            txtusid1.setText(rs.getString(2));
            txtusid.setText(rs.getString(3));
            cmbcat.setSelectedItem(rs.getString(4));
            txtcont.setText(rs.getString(5));
            cmbgen.setSelectedItem(rs.getString(6));
            String std = String.valueOf(rs.getDate(7));
            String std1 = Attendance.date(std);//03-mar-2012
            String st1 = std1.substring(0, 2);
            String st2 = std1.substring(3, 6);
            String st3 = std1.substring(7, 11);
            cmbdd.setSelectedItem(st1);
            cmbmm.setSelectedItem(st2);
            cmbyy.setSelectedItem(st3);
        } catch (Exception sqe) {
            JOptionPane.showMessageDialog(this, "No User Found", "New User Window", 0);
            total = 0;
        }
        if (total == 1) {
            btnupdate.setEnabled(true);
            btnnext1.setEnabled(true);
            btnprev1.setEnabled(true);
        } else {
            btnupdate.setEnabled(false);
            btnnext1.setEnabled(false);
            btnprev1.setEnabled(false);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel3 = new javax.swing.JPanel();
        cmbcat = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        txtcont = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtusid = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        cmbdd = new javax.swing.JComboBox();
        cmbmm = new javax.swing.JComboBox();
        cmbyy = new javax.swing.JComboBox();
        cmbgen = new javax.swing.JComboBox();
        jLabel11 = new javax.swing.JLabel();
        txtusid1 = new javax.swing.JTextField();
        btnupdate = new javax.swing.JButton();
        btnprev1 = new javax.swing.JButton();
        btnnext1 = new javax.swing.JButton();
        jpwd1 = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Modify  Users Window");
        setMinimumSize(new java.awt.Dimension(840, 600));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(102, 0, 102));
        jPanel3.setPreferredSize(new java.awt.Dimension(1360, 700));

        cmbcat.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        cmbcat.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Administrator", "User" }));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 0));
        jLabel1.setText("Modify All Users Window");
        jLabel1.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);

        txtcont.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        txtcont.setToolTipText("Enter Contact  Number To Modify And Use Only Digit(0-9) ");
        txtcont.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtcontFocusLost(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Modern No. 20", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 255, 255));
        jLabel3.setText("Contact No :");

        jLabel5.setFont(new java.awt.Font("Modern No. 20", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 255, 255));
        jLabel5.setText("Passoword :");

        jLabel6.setFont(new java.awt.Font("Modern No. 20", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 255, 255));
        jLabel6.setText("Cotegory :");

        jLabel7.setBackground(new java.awt.Color(255, 255, 0));
        jLabel7.setOpaque(true);

        jLabel8.setFont(new java.awt.Font("Modern No. 20", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 255, 255));
        jLabel8.setText("User Name :");

        txtusid.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        txtusid.setToolTipText("Enter User Name To Modify And Use Only a-z,A-Z,spaces");
        txtusid.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtusidFocusLost(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Modern No. 20", 1, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 255, 255));
        jLabel9.setText("Gender :");

        jLabel10.setFont(new java.awt.Font("Modern No. 20", 1, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 255, 255));
        jLabel10.setText("Joining Date :");

        cmbdd.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        cmbdd.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));

        cmbmm.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        cmbmm.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" }));

        cmbyy.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        cmbyy.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023" }));

        cmbgen.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        cmbgen.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Male", "Female" }));

        jLabel11.setFont(new java.awt.Font("Modern No. 20", 1, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 255, 255));
        jLabel11.setText("User ID :");

        txtusid1.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        txtusid1.setToolTipText("Enter User ID To Modify And Use Only a-z,A-Z,0-9");
        txtusid1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtusid1FocusLost(evt);
            }
        });

        btnupdate.setIcon(new javax.swing.ImageIcon(getClass().getResource("/EmployeeInformation/update.jpg"))); // NOI18N
        btnupdate.setToolTipText("Update All Changes");
        btnupdate.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnupdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnupdateActionPerformed(evt);
            }
        });

        btnprev1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/EmployeeInformation/prev1.jpg"))); // NOI18N
        btnprev1.setToolTipText("Previous");
        btnprev1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnprev1ActionPerformed(evt);
            }
        });

        btnnext1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/EmployeeInformation/nextt.jpg"))); // NOI18N
        btnnext1.setToolTipText("Next");
        btnnext1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnnext1ActionPerformed(evt);
            }
        });

        jpwd1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jpwd1.setToolTipText("Enter Password To Modify And Use Only a-z,A-Z,0-9 ");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(361, 361, 361)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(jLabel6)
                            .addComponent(jLabel9)
                            .addComponent(jLabel3)
                            .addComponent(jLabel5)
                            .addComponent(jLabel8)
                            .addComponent(jLabel11))
                        .addGap(50, 50, 50)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtcont, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmbcat, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(cmbdd, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(cmbmm, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(cmbyy, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(cmbgen, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtusid, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtusid1, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jpwd1, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(455, 455, 455)
                        .addComponent(btnprev1, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(42, 42, 42)
                        .addComponent(btnupdate, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(42, 42, 42)
                        .addComponent(btnnext1, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(278, 278, 278)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(25, 25, 25)
                                .addComponent(jLabel1))
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 580, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 4, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(79, 79, 79)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(txtusid1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtusid, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(jpwd1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(cmbcat, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtcont, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(cmbgen, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cmbdd, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(cmbmm, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(cmbyy, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(50, 50, 50)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnprev1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(btnnext1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnupdate, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 259, Short.MAX_VALUE))
        );

        jScrollPane2.setViewportView(jPanel3);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 1360, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 880, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:
        MdiWindow.jmi21.setEnabled(true);
    }//GEN-LAST:event_formWindowClosing

    private void btnnext1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnnext1ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = MdiWindow.con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            if (rs.next()) {
                jpwd1.setText(rs.getString(1));
                txtusid1.setText(rs.getString(2));
                txtusid.setText(rs.getString(3));
                cmbcat.setSelectedItem(rs.getString(4));
                txtcont.setText(rs.getString(5));
                cmbgen.setSelectedItem(rs.getString(6));
                String std = String.valueOf(rs.getDate(7));
                String std1 = Attendance.date(std);//03-mar-2012
                String st1 = std1.substring(0, 2);
                String st2 = std1.substring(3, 6);
                String st3 = std1.substring(7, 11);
                cmbdd.setSelectedItem(st1);
                cmbmm.setSelectedItem(st2);
                cmbyy.setSelectedItem(st3);
                ctr++;
            } else if (rs.isAfterLast()) {
                JOptionPane.showMessageDialog(rootPane, "You Were At Last Record", "Record test", JOptionPane.INFORMATION_MESSAGE, null);
                rs.absolute(1);
                jpwd1.setText(rs.getString(1));
                txtusid1.setText(rs.getString(2));
                txtusid.setText(rs.getString(3));
                cmbcat.setSelectedItem(rs.getString(4));
                txtcont.setText(rs.getString(5));
                cmbgen.setSelectedItem(rs.getString(6));
                String std = String.valueOf(rs.getDate(7));
                String std1 = Attendance.date(std);//03-mar-2012
                String st1 = std1.substring(0, 2);
                String st2 = std1.substring(3, 6);
                String st3 = std1.substring(7, 11);
                cmbdd.setSelectedItem(st1);
                cmbmm.setSelectedItem(st2);
                cmbyy.setSelectedItem(st3);
                ctr = 1;
            }
        } catch (Exception sqe) {
            JOptionPane.showMessageDialog(rootPane, "You Were At Last Record", "Record test", JOptionPane.INFORMATION_MESSAGE, null);
        }
    }//GEN-LAST:event_btnnext1ActionPerformed

    private void btnprev1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnprev1ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = MdiWindow.con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            if (rs.previous()) {
                jpwd1.setText(rs.getString(1));
                txtusid1.setText(rs.getString(2));
                txtusid.setText(rs.getString(3));
                cmbcat.setSelectedItem(rs.getString(4));
                txtcont.setText(rs.getString(5));
                cmbgen.setSelectedItem(rs.getString(6));
                String std = String.valueOf(rs.getDate(7));
                String std1 = Attendance.date(std);//03-mar-2012
                String st1 = std1.substring(0, 2);
                String st2 = std1.substring(3, 6);
                String st3 = std1.substring(7, 11);
                cmbdd.setSelectedItem(st1);
                cmbmm.setSelectedItem(st2);
                cmbyy.setSelectedItem(st3);
                ctr--;
            } else if (rs.isBeforeFirst()) {
                JOptionPane.showMessageDialog(rootPane, "You Were At First Record", "Record test", JOptionPane.INFORMATION_MESSAGE, null);
                rs.last();
                jpwd1.setText(rs.getString(1));
                txtusid1.setText(rs.getString(2));
                txtusid.setText(rs.getString(3));
                cmbcat.setSelectedItem(rs.getString(4));
                txtcont.setText(rs.getString(5));
                cmbgen.setSelectedItem(rs.getString(6));
                String std = String.valueOf(rs.getDate(7));
                String std1 = Attendance.date(std);//03-mar-2012
                String st1 = std1.substring(0, 2);
                String st2 = std1.substring(3, 6);
                String st3 = std1.substring(7, 11);
                cmbdd.setSelectedItem(st1);
                cmbmm.setSelectedItem(st2);
                cmbyy.setSelectedItem(st3);
                ctr = 0;
                try {
                    stmt1 = MdiWindow.con.createStatement(rs1.TYPE_SCROLL_INSENSITIVE, rs1.CONCUR_UPDATABLE);
                    String str = "select * from userlogin";
                    rs1 = stmt1.executeQuery(str);
                    while (rs1.next()) {
                        ctr++;
                    }
                } catch (Exception sqe) {
                    JOptionPane.showMessageDialog(this, sqe.getMessage(), "New User Window", 0);
                }
            }
        } catch (Exception sqe) {
            JOptionPane.showMessageDialog(this, sqe.getMessage(), "New User Window", 0);
        }
    }//GEN-LAST:event_btnprev1ActionPerformed

    private void btnupdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnupdateActionPerformed
        // TODO add your handling code here:
        int admin = 0;
        int chk = 0;
        String usid = "";
        String usid1 = "";
        String password1 = "";
        String jpwd = jpwd1.getText().toLowerCase();
        String arg = String.valueOf(cmbdd.getSelectedItem());//03-may-2012
        String arg1 = String.valueOf(cmbmm.getSelectedItem());
        String arg2 = String.valueOf(cmbyy.getSelectedItem());
        String arg3 = arg.concat("-").concat(arg1).concat("-").concat(arg2);
        String cont = "+91";
        String pwd = "";
        if (txtcont.getText().startsWith("+91")) {
        } else {
            txtcont.setText(cont.concat(txtcont.getText()));
        }
        if (txtusid1.getText().equals("") || txtusid.getText().equals("") || jpwd.equals("")) {
            JOptionPane.showMessageDialog(rootPane, "Please Fillup the all Fields", "", JOptionPane.INFORMATION_MESSAGE);
        } else if (txtcont.getText().length() != 13) {
            JOptionPane.showMessageDialog(this, "Please Enter Valid Contact No.", "", JOptionPane.INFORMATION_MESSAGE);
        } else {
            String password = "hussain";
            String userid = "asifbca486";
            if (password.equalsIgnoreCase(jpwd) || userid.equalsIgnoreCase(txtusid1.getText())) {
                admin = 1;
            } else {
                try {
                    stmt1 = MdiWindow.con.createStatement(rs1.TYPE_SCROLL_INSENSITIVE, rs1.CONCUR_UPDATABLE);
                    String str1 = "select pwd,usid from userlogin";
                    rs1 = stmt1.executeQuery(str1);
                    while (rs1.next()) {
                        password1 = rs1.getString(1);
                        usid = rs1.getString(2);
                        if (password1.equals(jpwd) && usid.equals(txtusid1.getText())) {
                            chk = 1;
                            break;
                        } else if (usid.equalsIgnoreCase(txtusid1.getText())) {
                            chk = 2;
                            break;
                        }
                    }
                } catch (Exception ex) {
                }
            }
            try {
                stmt = MdiWindow.con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
                String sql = "select * from userlogin";
                rs = stmt.executeQuery(sql);
                rs.absolute(ctr);
                pwd = rs.getString(1);
                usid1 = rs.getString(2);
                if (usid1.equals(usid)) {
                    chk = 1;
                } else if (usid.equalsIgnoreCase(txtusid1.getText())) {
                    chk = 2;
                } else {
                    chk = 1;
                }
            } catch (Exception Exc) {
                JOptionPane.showMessageDialog(rootPane, "Error Occured, While Updating Records Due To "
                        + Exc, "Updatation test", JOptionPane.ERROR_MESSAGE, null);
            }
            if (chk == 1 && admin == 0) {
                try {
                    String str1 = "select pwd,usid from userlogin";
                    rs1 = stmt1.executeQuery(str1);
                    while (rs1.next()) {
                        password1 = rs1.getString(1);
                        if (pwd.equalsIgnoreCase(jpwd1.getText())) {
                            jpwd = jpwd1.getText();
                        } else if (jpwd1.getText().equalsIgnoreCase(password1)) {
                            jpwd = password1;
                            break;
                        } else {
                            jpwd = jpwd1.getText();
                        }
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, ex.toString());
                }
                try {
                    stmt1 = MdiWindow.con.createStatement(rs1.TYPE_SCROLL_INSENSITIVE, rs1.CONCUR_UPDATABLE);
                    String str = "update userlogin set pwd='" + jpwd + "',usid='" + txtusid1.getText() + "',user_name='" + txtusid.getText() + "',cat='" + cmbcat.getSelectedItem() + "',contact='" + txtcont.getText() + "',gender='" + cmbgen.getSelectedItem() + "',joindate='" + arg3 + "' where pwd='" + pwd + "'";
                    stmt1.executeUpdate(str);
                    MdiWindow.con.setAutoCommit(true);
                    JOptionPane.showMessageDialog(rootPane, "Record is Sucessfilly Updated ", "Updatation test", JOptionPane.INFORMATION_MESSAGE, null);
                } catch (Exception Exc) {
                    JOptionPane.showMessageDialog(rootPane, "This User ID/Password has allready been exist", "Updatation test", JOptionPane.ERROR_MESSAGE, null);
                }
            } else {
                if (admin == 0) {
                    JOptionPane.showMessageDialog(rootPane, "This User ID/Password has allready been exist", "Updatation test", JOptionPane.ERROR_MESSAGE, null);
                } else {
                    JOptionPane.showMessageDialog(rootPane, "User Not Updated. Invalid Entry", "Updatation test", JOptionPane.ERROR_MESSAGE, null);
                }
            }
        }
    }//GEN-LAST:event_btnupdateActionPerformed

    private void txtusid1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtusid1FocusLost
        // TODO add your handling code here:
        if (txtusid1.getText().matches("[a-zA-Z-0-9]*")) {
        } else {
            txtusid1.setText("");
        }
    }//GEN-LAST:event_txtusid1FocusLost

    private void txtusidFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtusidFocusLost
        // TODO add your handling code here:
        if (txtusid.getText().matches("[a-zA-Z- ]*")) {
        } else {
            txtusid.setText("");
        }
    }//GEN-LAST:event_txtusidFocusLost

    private void txtcontFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtcontFocusLost
        // TODO add your handling code here:
        if (txtcont.getText().matches("\\d*") || txtcont.getText().matches("[+]\\d*")) {
        } else {
            txtcont.setText("+91");
        }
    }//GEN-LAST:event_txtcontFocusLost

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnnext1;
    private javax.swing.JButton btnprev1;
    private javax.swing.JButton btnupdate;
    private javax.swing.JComboBox cmbcat;
    private javax.swing.JComboBox cmbdd;
    private javax.swing.JComboBox cmbgen;
    private javax.swing.JComboBox cmbmm;
    private javax.swing.JComboBox cmbyy;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jpwd1;
    private javax.swing.JTextField txtcont;
    private javax.swing.JTextField txtusid;
    private javax.swing.JTextField txtusid1;
    // End of variables declaration//GEN-END:variables
}
